-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s12p11a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `todocontribution`
--

DROP TABLE IF EXISTS `todocontribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `todocontribution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `cnt` tinyint(4) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_date` (`userId`,`date`),
  KEY `idx_user_id` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todocontribution`
--

LOCK TABLES `todocontribution` WRITE;
/*!40000 ALTER TABLE `todocontribution` DISABLE KEYS */;
INSERT INTO `todocontribution` VALUES (26,7,1,'2025-02-14'),(123,5,1,'2025-02-17'),(125,7,1,'2025-02-18'),(130,5,1,'2025-02-18'),(168,1,2,'2025-02-20'),(170,7,6,'2025-02-20'),(175,8,2,'2025-02-10'),(177,8,2,'2025-02-11'),(179,8,3,'2025-02-13'),(182,8,1,'2025-02-16'),(183,8,1,'2024-12-31'),(184,8,1,'2025-01-08'),(185,8,5,'2025-01-09'),(190,8,1,'2024-12-30'),(191,8,1,'2024-12-26'),(192,8,3,'2025-01-15'),(195,8,1,'2025-01-20'),(196,8,1,'2025-01-21'),(198,8,2,'2025-01-25'),(200,8,5,'2025-02-05'),(205,8,2,'2024-12-23'),(207,8,1,'2024-12-18'),(208,8,3,'2024-12-17'),(211,8,1,'2024-12-16'),(212,8,3,'2024-12-15'),(215,8,1,'2024-12-10'),(217,7,1,'2025-02-06'),(218,7,4,'2025-02-05'),(223,7,1,'2025-01-28'),(224,7,1,'2025-01-26'),(225,7,7,'2025-01-03'),(232,7,3,'2025-01-05'),(235,7,3,'2025-01-06'),(238,7,1,'2025-01-07'),(239,7,3,'2025-01-15'),(242,7,2,'2025-01-17'),(244,7,5,'2025-01-20'),(249,18,1,'2025-02-18'),(250,18,3,'2025-02-14'),(256,4,3,'2025-02-20'),(259,8,2,'2025-02-19'),(268,13,4,'2025-02-20'),(280,4,1,'2024-12-31'),(281,4,1,'2024-12-30'),(282,4,2,'2024-12-08'),(283,4,1,'2025-02-18'),(284,4,1,'2024-12-23'),(286,4,1,'2024-12-22'),(287,4,2,'2025-02-10'),(289,4,1,'2024-12-05'),(291,4,2,'2024-12-01');
/*!40000 ALTER TABLE `todocontribution` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-20 19:20:48
