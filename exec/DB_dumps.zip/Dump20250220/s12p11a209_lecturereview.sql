-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s12p11a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lecturereview`
--

DROP TABLE IF EXISTS `lecturereview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lecturereview` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lectureId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `rating` float(2,1) NOT NULL CHECK (`rating` between 0 and 5),
  `content` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_userId` (`userId`),
  KEY `idx_lectureId` (`lectureId`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecturereview`
--

LOCK TABLES `lecturereview` WRITE;
/*!40000 ALTER TABLE `lecturereview` DISABLE KEYS */;
INSERT INTO `lecturereview` VALUES (1,2391,4,4.5,'타입스크립트 엄청 쉽게 설명해주세요!','2025-02-11 01:23:11'),(7,2100,8,5.0,'test2','2025-02-12 04:26:18'),(9,2100,5,4.0,'하잉','2025-02-12 05:18:45'),(10,2150,5,5.0,'ㅇㅇd','2025-02-12 05:19:49'),(12,2150,8,5.0,'test','2025-02-12 05:20:48'),(30,2163,5,5.0,'안녕하세용 \n','2025-02-13 08:57:15'),(32,2500,4,2.5,'리뷰 테스트 할게요!!!!!!!!!제발!!!!!!!!!!!!!!!!!!','2025-02-16 08:11:59'),(39,2150,7,0.5,'ㅋ','2025-02-18 08:09:12'),(40,2151,7,0.5,'ㅁ','2025-02-18 08:09:21'),(41,2152,7,2.5,'너무 어려워요','2025-02-18 08:09:29'),(42,2153,7,3.5,'Dart 낯설지만 재밌어요!','2025-02-18 08:09:37'),(43,2150,9,1.5,'최고','2025-02-19 00:56:57'),(45,2150,9,4.5,'최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고최고','2025-02-19 01:39:14'),(46,2959,18,4.5,'이 강의 진짜 히트입니다.','2025-02-19 04:34:41'),(47,3000,4,5.0,'리뷰 테스트!!!!!!!!!!!!!','2025-02-19 06:40:52'),(48,3100,4,5.0,'첫 리뷰입니당!','2025-02-19 11:36:10'),(49,3400,4,4.5,'첫 리뷰입니당!#! 너무 재밌게 잘 들었오요!!!!!!!!!!!!!!!!!!!!!!!!!!','2025-02-19 11:37:10'),(50,2201,7,2.5,'파이썬 어려워요!','2025-02-20 01:09:26'),(51,2340,18,3.5,'파이썬 공부할 겸 같이 들었는데 재밌게 알려주셔서 좋습니다. 다만 강의가 너무 짧은 것 같아요.','2025-02-20 03:53:16'),(52,2340,8,5.0,'듣기 딱 좋은 속도네요!!','2025-02-20 03:55:44'),(53,5000,4,5.0,'처음 배우시는 분들께 추천드립니다!!!','2025-02-20 05:24:40'),(54,3101,4,4.5,'추천합니다!','2025-02-20 06:02:17'),(55,5001,4,4.5,'너무 상세하게 설명해주셔서 노베이신 분들이 들으시면 좋을 것 같습니다.','2025-02-20 06:25:29'),(56,6315,7,4.0,'이 강의 지금 구름edu에서 할인 중이래요~','2025-02-20 07:51:06'),(57,5141,8,4.5,'이 강의 덕분에 프로젝트에 필요한 크롤링 시스템을 만들 수 있었습니다!!','2025-02-20 08:03:32');
/*!40000 ALTER TABLE `lecturereview` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-20 19:20:51
