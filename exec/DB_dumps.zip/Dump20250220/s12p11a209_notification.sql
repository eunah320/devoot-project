-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s12p11a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `toUserId` bigint(20) NOT NULL,
  `fromUserId` bigint(20) NOT NULL,
  `followId` bigint(20) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `hasRead` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_to_user_id` (`toUserId`),
  KEY `idx_follow_id` (`followId`),
  KEY `idx_from_user_id` (`fromUserId`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (3,2,1,3,'2025-02-08 14:19:21',0),(4,3,1,5,'2025-02-08 14:55:18',1),(5,3,2,7,'2025-02-08 17:51:39',1),(6,5,3,8,'2025-02-10 04:45:57',1),(7,2,5,9,'2025-02-10 08:39:11',0),(8,6,5,10,'2025-02-10 08:40:12',1),(9,6,7,11,'2025-02-11 03:48:42',1),(24,9,5,27,'2025-02-13 08:52:01',1),(29,6,4,32,'2025-02-16 07:14:20',1),(41,13,1,44,'2025-02-16 08:39:02',1),(42,7,1,45,'2025-02-16 08:49:36',1),(43,10,5,46,'2025-02-16 15:31:28',1),(44,1,5,47,'2025-02-16 15:39:00',1),(47,7,4,50,'2025-02-17 00:40:42',1),(48,7,5,51,'2025-02-17 16:22:53',1),(49,1,6,52,'2025-02-17 16:24:38',1),(50,5,6,53,'2025-02-17 16:25:37',1),(51,4,6,54,'2025-02-17 16:25:40',1),(52,7,6,55,'2025-02-17 16:25:43',1),(53,9,6,56,'2025-02-17 16:25:51',1),(56,4,5,59,'2025-02-18 16:27:54',1),(57,1,4,60,'2025-02-18 16:34:22',1),(58,13,4,61,'2025-02-18 16:34:25',1),(59,17,4,62,'2025-02-18 16:34:29',1),(60,8,4,63,'2025-02-18 16:34:35',1),(61,9,4,64,'2025-02-18 16:34:41',1),(62,10,4,65,'2025-02-18 16:34:44',0),(64,2,4,67,'2025-02-18 16:34:53',0),(65,5,4,68,'2025-02-18 16:35:01',1),(66,3,4,69,'2025-02-18 16:35:19',0),(67,7,18,70,'2025-02-19 01:18:06',1),(68,1,7,71,'2025-02-20 01:04:12',1),(69,18,8,72,'2025-02-20 04:05:05',1),(70,18,7,73,'2025-02-20 04:40:21',1),(71,13,5,74,'2025-02-20 06:17:29',1),(72,8,5,75,'2025-02-20 06:51:51',1),(73,5,13,76,'2025-02-20 07:02:38',1);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-20 19:20:53
