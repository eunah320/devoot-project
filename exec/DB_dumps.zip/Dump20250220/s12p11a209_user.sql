-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s12p11a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `profileId` varchar(15) COLLATE utf8mb4_bin DEFAULT NULL,
  `nickname` varchar(18) COLLATE utf8mb4_bin DEFAULT NULL,
  `links` longtext COLLATE utf8mb4_bin DEFAULT NULL,
  `isPublic` tinyint(1) DEFAULT 1,
  `imageUrl` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  `uid` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `tags` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `isBlocked` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profileId` (`profileId`),
  KEY `idx_profileid` (`profileId`),
  KEY `idx_nickname` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'qhsl99@sookmyung.ac.kr','l3olvy','보니','{\"title\":\"깃허브\",\"url\":\"https://github.com/l3olvy\"}',1,'https://devoot-profile-image.s3.amazonaws.com/profile/1-14a9fdfc.jpg','CydJBjNURdgjkzpmaP5Ig8ovpLh1','데이터 분석,Java,Dart','2025-02-08 13:52:50',0),(2,'qhsl0615@gmail.com','bon','뽄드','',1,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','TBaZ1sL7R7VAIvVaLsdmSNkuANy2','데이터 분석','2025-02-08 13:59:15',0),(3,'boni990615@gmail.com','private','쉿비밀','',0,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','ihqiBzSvDXY4rCmEgdD81yWSlH52','Go,Scala,TypeScript','2025-02-08 13:59:47',0),(4,'seungju425@gmail.com','sj','승주','{\"title\":\"승주 노션 놀러 오세요~~~~~~~~\",\"url\":\"https://github.com/\"}',1,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','tU6Mr4RHtQNApgoLNTS2Y76V4ig2','HTML,JavaScript,Ruby,임베디드/IoT','2025-02-10 03:49:00',0),(5,'eunah320@gmail.com','eunah','몽땅이','',1,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','gK0HMqDicTQt4XpCNaEPWxMVWL83','Python','2025-02-10 04:39:09',0),(6,'grhpfam@gmail.com','eunah2_official','으나2','',0,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','w97D0lv6eiRL4RWVwFwf4rWKXcn2','HTML,JavaScript,Java,Ruby,MySQL','2025-02-10 05:02:28',0),(7,'devoot209@gmail.com','devoot','신입개발자','',1,'https://devoot-profile-image.s3.amazonaws.com/profile/7-8f54410.jpg','YDS84AGwjeamffib78Ck6Lp1LnB3','시스템/운영체제,블록체인,임베디드/IoT','2025-02-10 06:01:25',0),(8,'devoot2@gmail.com','devoot2','서당개삼년이면','',0,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','qiYnrSwlDfeOX3Q9YdSG8cgPLwh1','JavaScript','2025-02-12 04:26:00',0),(9,'irene.k2547@gmail.com','nahyun','나현','{\"title\":\"깃허브\",\"url\":\"www.github.com\"}',1,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','5htIYBnLLCXzdA9mkYZ2CPVMq3M2','HTML','2025-02-13 02:05:30',0),(10,'123@gmail.com','nahyun_github','나현2','{\"title\":\"\",\"url\":\"\"}',0,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7LpapIl8DITfz4_Y2z7pqs7FknPkjReAZCg&s','9WTeNy1SFFYA7IFHIdVcSJUL2WJ3','JavaScript','2025-02-13 02:29:48',0),(13,'l3olvy@gmail.com','l3on','뽕뽕','',1,NULL,'r8tXUYbJ7KX7Ca7bn8X41KP2aOp2','MySQL,Markdown','2025-02-14 01:47:14',0),(14,'nahyun2547@kookmin.ac.kr','nahyun_4','나현3','',1,NULL,'dABE50vpbqf9XipBSNh2Xt03SVm1','HTML','2025-02-14 04:02:50',0),(15,'sally_0425@naver.com','seungju','승주 다시 만들엇용','{&quot;title&quot;:&quot;&quot;,&quot;url&quot;:&quot;&quot;}',1,NULL,'iOa5LVnotOT9pAbQd4HQ9g3cVg02','JavaScript,Dart,데이터 엔지니어링','2025-02-17 07:43:58',0),(17,'l3olvyy@gmail.com','l3olvyy','본','',1,NULL,'LOX1Bgj3feetMV55FmWFARHAiSe2','데이터 엔지니어링,자연어 처리,임베디드/IoT','2025-02-18 03:46:43',0),(18,'kiw970923@gmail.com','kiw970923','코딩하는나그네','{\"title\":\"네이버블로그\",\"url\":\"https://blog.naver.com/no_spell_compile\"}',1,'https://devoot-profile-image.s3.amazonaws.com/profile/18-ba88dcf1.jpg','rSuW1Y2W3Vg6Yv4OtTDjRkt7yXK2','Java,시스템/운영체제,MySQL,데이터 엔지니어링','2025-02-19 01:10:04',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-20 19:20:50
